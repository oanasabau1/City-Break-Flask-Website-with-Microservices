from setuptools import setup, find_packages

setup(
    name='microskel',
    version='0.1.0',
    packages=find_packages(),
    package_data={'microskel': ['*.ini']},
    author='Paul'
)
